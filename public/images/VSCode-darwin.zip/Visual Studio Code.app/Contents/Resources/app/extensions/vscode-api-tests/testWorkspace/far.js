function farboo() {
	return 42;
}