The JavaScriptReact.tmLanguage bundle is derived from the TypeScriptReact.tmLanguage.

Changes:
- fileTypes -> .jsx
- scopeName -> scope.jsx
